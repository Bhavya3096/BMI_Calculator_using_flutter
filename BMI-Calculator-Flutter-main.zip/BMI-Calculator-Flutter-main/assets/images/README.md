# App Icon

Please add your `bmi_icon.png` file to this directory.

The icon should be:
- 1024x1024 pixels for best quality
- PNG format
- Named exactly: `bmi_icon.png`

After adding the icon, run:
```
flutter pub get
flutter pub run flutter_launcher_icons
```